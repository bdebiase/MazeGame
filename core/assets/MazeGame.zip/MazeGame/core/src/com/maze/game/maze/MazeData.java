package com.maze.game.maze;

public class MazeData {
    public String id;
    public String name;
    public int[][][] map;
}
