package com.maze.game.items;

public enum ItemType {
    NONE,
    KNIFE
}
