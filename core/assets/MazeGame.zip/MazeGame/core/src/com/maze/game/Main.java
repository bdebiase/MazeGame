package com.maze.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.maze.game.entities.Entity;
import com.maze.game.entities.Player;
import com.maze.game.entities.Rat;
import com.maze.game.maze.GameMap;
import com.maze.game.maze.TileType;
import com.maze.game.maze.TiledGameMap;

public class Main extends ApplicationAdapter {
	boolean gameStarted;

	SpriteBatch batch;
	OrthographicCamera camera;
	public static GameMap gameMap;

	private Stage stage;

	@Override
	public void create() {
		batch = new SpriteBatch();

		camera = new OrthographicCamera();
		camera.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
		camera.update();

		newMap();

		if (!gameStarted) {
			stage = new Stage();
			Gdx.input.setInputProcessor(stage);

			Skin skin = new Skin(Gdx.files.internal("uiskin.json"));

			Label.LabelStyle labelStyle = new Label.LabelStyle();
			BitmapFont font = new BitmapFont(Gdx.files.internal("font.fnt"));
			labelStyle.font = font;
			labelStyle.fontColor = Color.WHITE;

			Label label = new Label("Controls: Arrow keys to move.\nObjective: Dodge the rats and kill the Minotaur to escape!\nA sword can be used to slay the Minotaur.", labelStyle);
			label.setAlignment(Align.center);
			label.setSize(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
			label.setPosition(0, 100);

			TextButton.TextButtonStyle textButtonStyle = new TextButton.TextButtonStyle();
			textButtonStyle.up = skin.newDrawable("white", Color.GRAY);
			textButtonStyle.down = skin.newDrawable("white", Color.DARK_GRAY);
			textButtonStyle.font = font;
			TextButton btn = new TextButton("Start Game", textButtonStyle);
			btn.setPosition(Gdx.graphics.getWidth() / 2 - btn.getWidth() / 2, 300);
			btn.addListener(new ClickListener() {
				@Override
				public void touchUp(InputEvent e, float x, float y, int point, int button) {
					gameStarted = true;
				}
			});

			stage.addActor(label);
			stage.addActor(btn);
		}
	}

	@Override
	public void render() {
		if (!gameStarted) {
			Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
			stage.act(Gdx.graphics.getDeltaTime());
			stage.draw();
		} else {
			Gdx.gl.glClearColor(0, 0, 0, 1);
			Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
			Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

			camera.update();
			gameMap.update(Gdx.graphics.getDeltaTime());
			gameMap.render(camera, batch);
		}
	}

	@Override
	public void dispose () {
		batch.dispose();
		gameMap.dispose();
	}

	public static void newMap() {
		gameMap = new TiledGameMap();
		gameMap.player.setPosition(gameMap.getStartTilePosition());
		gameMap.player.hasSword(false);
		gameMap.minotaur.setPosition(gameMap.getMinotaurTilePosition());
		gameMap.minotaur.isDead(false);
		gameMap.sword.setPosition(gameMap.getSwordTilePosition());
		gameMap.rat.setPosition(gameMap.getRatTilePosition());
	}
}