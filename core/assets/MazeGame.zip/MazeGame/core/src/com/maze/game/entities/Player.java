package com.maze.game.entities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.maze.game.Main;
import com.maze.game.maze.GameMap;
import com.maze.game.maze.TileType;

public class Player extends Entity {
    public static final int SPEED = 6;
    public static final int ACCEL = 20;

    protected Vector2 _input;
    protected boolean _hasSword;

    private float deltaTime;

    public Player(Vector2 position, Texture texture, GameMap gameMap) {
        super(position, texture, gameMap);
    }

    public boolean hasSword() { return _hasSword; }

    public void hasSword(boolean val) { _hasSword = val; }

    @Override
    public void render(SpriteBatch batch) {
        batch.draw(_texture, _position.x, _position.y, _texture.getWidth(), _texture.getHeight());
    }

    @Override
    public void update(float deltaTime) {
        this.deltaTime = deltaTime;
        getInput();

        if (checkForSword()) {
            _hasSword = true;
        }

        _position.x += _velocity.x;
        _position.y += _velocity.y;

        getVelocity();

        if (_gameMap.getTileTypeByLocation(0, _position.x, _position.y) == TileType.END && _gameMap.minotaur.isDead())
            Main.newMap();
    }

    public Vector2 getInput() {
        _input = new Vector2(
                boolToInt(Gdx.input.isKeyPressed(Input.Keys.RIGHT)) - boolToInt(Gdx.input.isKeyPressed(Input.Keys.LEFT)),
                boolToInt(Gdx.input.isKeyPressed(Input.Keys.UP)) - boolToInt(Gdx.input.isKeyPressed(Input.Keys.DOWN)));
        _input.clamp(-1, 1);

        return _input;
    }

    public Vector2 getVelocity() {
        Vector2 posCheck = _position;

        _velocity.x = MathUtils.lerp(_velocity.x, _input.x * SPEED, ACCEL * deltaTime);
        _velocity.y = MathUtils.lerp(_velocity.y, _input.y * SPEED, ACCEL * deltaTime);

        if (_gameMap.doesRectCollideWithMap(_position.x + _velocity.x, _position.y + _velocity.y, _texture.getWidth(), _texture.getHeight())) {
            _position = posCheck;
            _velocity = new Vector2(0, 0);
        }

        return _velocity;
    }

    public boolean checkForSword() {
        return _gameMap.getTileTypeByLocation(1, _position.x, _position.y) == TileType.SWORD_SPAWNER;
    }

    public void setVelocity(Vector2 velocity) { _velocity = velocity; }

    private int boolToInt(boolean bool) {
        return bool ? 1 : 0;
    }
}
